﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.IO;
using System.Diagnostics;
namespace BMPXMLJSGV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        BinaryReader bmpFile;
        string localPath;
        public string Validar()//metodo solo para este programa , si no lo tenía así no funcionaba.
        {
            localPath = textBox1.Text;
            
            return localPath;
        }





        private void button1_Click(object sender, EventArgs e)
        {


            {
                string localpath = Validar();
                string extension;
                extension = Path.GetExtension(localpath);
                if (extension == ".bmp")
                {
                    int bitsPerPixel = 0;
                    int ancho = 0;
                    int alto = 0;
                    int tamañoArchivo = 0;
                    BinaryReader bmpFile;

                    bmpFile = new BinaryReader(File.OpenRead(localpath)); //Lee la ruta como un archivo binario 
                    bmpFile.BaseStream.Seek(18, SeekOrigin.Begin);// De acuerdo a la estructura del .bmp of course :)

                    ancho = bmpFile.ReadInt32();
                    alto = bmpFile.ReadInt32();


                    bmpFile.BaseStream.Seek(2, SeekOrigin.Current);

                    bitsPerPixel = bmpFile.ReadInt16();

                    bmpFile.BaseStream.Seek(4, SeekOrigin.Current);
                    tamañoArchivo = bmpFile.ReadInt32();



                    bmpFile.Close();
                    String información = "Los datos de tu archivo BMP son los siguientes "+ Environment.NewLine +"Ancho: " + ancho.ToString() + ", alto :" + alto.ToString() + ", Bits por pixel :" + bitsPerPixel.ToString() + ", Tamaño " + tamañoArchivo.ToString() + "bytes";

                    //SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    //saveFileDialog1.Filter = "|Extended Markup Lenguage|*.xml|";
                    //saveFileDialog1.ShowDialog();

                    string path = textBox2.Text;

                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    FileStream fs = File.Create(path);
                    fs.Close();
                    StreamWriter sw = new StreamWriter(path);
                    const string quote = "\"";
                    String escribir = "<?xml version=" + quote + "1.0" + quote + " encoding=" + quote + "UTF-8" + quote + "standalone=" + quote + "yes" + quote + "?>" + Environment.NewLine +
                         "<texto>" + Environment.NewLine
                    + "<mensaje>" + Environment.NewLine + información + Environment.NewLine + "</mensaje>" + Environment.NewLine + "</texto>";
                    sw.WriteLine(escribir);
                    sw.Close();
                    Process.Start(path);
                    textBox3.Text = información;
                }
                else
                {
                    MessageBox.Show("No es un archivo bmp amiguito");
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
