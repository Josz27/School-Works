﻿namespace PracticaBits
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProcesar = new System.Windows.Forms.Button();
            this.textboxID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.laFecha = new System.Windows.Forms.DateTimePicker();
            this.textBoxFecha = new System.Windows.Forms.TextBox();
            this.btnFecha = new System.Windows.Forms.Button();
            this.pBoxDireccion = new System.Windows.Forms.PictureBox();
            this.pBoxTanque = new System.Windows.Forms.PictureBox();
            this.pBoxSensores = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxDireccion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxTanque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxSensores)).BeginInit();
            this.SuspendLayout();
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(394, 28);
            this.btnProcesar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(112, 34);
            this.btnProcesar.TabIndex = 0;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.button1_Click);
            // 
            // textboxID
            // 
            this.textboxID.Location = new System.Drawing.Point(196, 28);
            this.textboxID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textboxID.MaxLength = 3;
            this.textboxID.Name = "textboxID";
            this.textboxID.Size = new System.Drawing.Size(148, 27);
            this.textboxID.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ingrese Número ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Estado(Sensores)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 312);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nivel de Tanque";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(584, 79);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Dirección";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(689, 438);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "Fecha de Lectura.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 495);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "Fecha";
            // 
            // laFecha
            // 
            this.laFecha.Location = new System.Drawing.Point(89, 495);
            this.laFecha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.laFecha.Name = "laFecha";
            this.laFecha.Size = new System.Drawing.Size(298, 27);
            this.laFecha.TabIndex = 9;
            // 
            // textBoxFecha
            // 
            this.textBoxFecha.Location = new System.Drawing.Point(129, 547);
            this.textBoxFecha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxFecha.MaxLength = 3;
            this.textBoxFecha.Name = "textBoxFecha";
            this.textBoxFecha.Size = new System.Drawing.Size(148, 27);
            this.textBoxFecha.TabIndex = 10;
            // 
            // btnFecha
            // 
            this.btnFecha.Location = new System.Drawing.Point(460, 493);
            this.btnFecha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFecha.Name = "btnFecha";
            this.btnFecha.Size = new System.Drawing.Size(147, 34);
            this.btnFecha.TabIndex = 11;
            this.btnFecha.Text = "Ajustar Fecha";
            this.btnFecha.UseVisualStyleBackColor = true;
            this.btnFecha.Click += new System.EventHandler(this.btnFecha_Click);
            // 
            // pBoxDireccion
            // 
            this.pBoxDireccion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBoxDireccion.Location = new System.Drawing.Point(415, 102);
            this.pBoxDireccion.Margin = new System.Windows.Forms.Padding(4);
            this.pBoxDireccion.Name = "pBoxDireccion";
            this.pBoxDireccion.Size = new System.Drawing.Size(429, 320);
            this.pBoxDireccion.TabIndex = 14;
            this.pBoxDireccion.TabStop = false;
            // 
            // pBoxTanque
            // 
            this.pBoxTanque.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBoxTanque.Location = new System.Drawing.Point(243, 263);
            this.pBoxTanque.Margin = new System.Windows.Forms.Padding(4);
            this.pBoxTanque.Name = "pBoxTanque";
            this.pBoxTanque.Size = new System.Drawing.Size(127, 140);
            this.pBoxTanque.TabIndex = 13;
            this.pBoxTanque.TabStop = false;
            // 
            // pBoxSensores
            // 
            this.pBoxSensores.Location = new System.Drawing.Point(194, 79);
            this.pBoxSensores.Margin = new System.Windows.Forms.Padding(4);
            this.pBoxSensores.Name = "pBoxSensores";
            this.pBoxSensores.Size = new System.Drawing.Size(150, 136);
            this.pBoxSensores.TabIndex = 12;
            this.pBoxSensores.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(255)))), ((int)(((byte)(230)))));
            this.ClientSize = new System.Drawing.Size(851, 634);
            this.Controls.Add(this.pBoxDireccion);
            this.Controls.Add(this.pBoxTanque);
            this.Controls.Add(this.pBoxSensores);
            this.Controls.Add(this.btnFecha);
            this.Controls.Add(this.textBoxFecha);
            this.Controls.Add(this.laFecha);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textboxID);
            this.Controls.Add(this.btnProcesar);
            this.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBoxDireccion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxTanque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxSensores)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.TextBox textboxID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker laFecha;
        private System.Windows.Forms.TextBox textBoxFecha;
        private System.Windows.Forms.Button btnFecha;
        private System.Windows.Forms.PictureBox pBoxSensores;
        private System.Windows.Forms.PictureBox pBoxTanque;
        private System.Windows.Forms.PictureBox pBoxDireccion;
    }
}

