﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaBits
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numeroID;
            numeroID = Convert.ToInt32(textboxID.Text);
            string info = Convert.ToString(numeroID, 2);
            string info2 = info;
            int size = info.Length;
            string datos = "";

            //_______________________________________________________________________________//
            if (numeroID <= 255)
            {
                for (int k = size, k2 = 0; k < 8; k++)
                {
                    datos += "0";
                    k2++;
                }
                //_______________________________________________________________________________//
                string x = "";
                string x2 = "";
                datos = datos + "" + info2;
                char cambio;

                for (int q = 0; q < 8; q++)
                {
                    cambio = datos[q];

                    //Indicador de nivel
                    if (q == 2 || q == 3)
                    {
                        x += datos[q];

                    }
                    //Dirección Rosa de los Vientos
                    else if (q >= 4 && q <= 6)
                    {
                        x2 += datos[q];
                    }
                    //_______________________________________________________________________________//
                    //Imágenes
                    pBoxSensores.SizeMode = PictureBoxSizeMode.StretchImage;
                    if (q == 0)
                     //Sensores
                    {
                        if (cambio == '1')
                        {
                            
                            pBoxSensores.Image = PracticaBits.Properties.Resources.Encendido;
                            
                        }
                        else if (cambio == '0')
                        {
                           
                            pBoxSensores.Image = PracticaBits.Properties.Resources.Apagado;
                           

                        }

                    }
                    else if (q == 1)
                    {
                        if (cambio == '1')
                    {
                           
                            pBoxSensores.Image = PracticaBits.Properties.Resources.Encendido;
                    }
                    else if (cambio == '0')
                    {
                           
                            pBoxSensores.Image = PracticaBits.Properties.Resources.Apagado;
                           
                        }
            }
        }
                //_________________________________________________________________________________//

                //Niveles
                if (x == "00")
                {
                    pBoxTanque.Image = PracticaBits.Properties.Resources.Vacio;
                }
                else if (x=="01")
                {
                    pBoxTanque.Image = PracticaBits.Properties.Resources.Medio;
                }
                else if (x == "10")
                {
                    pBoxTanque.Image = PracticaBits.Properties.Resources.Lleno;
                }
                else if (x == "10")
                {
                    pBoxTanque.Image = PracticaBits.Properties.Resources.En_Proceso;
                }
                //_________________________________________________________________________________//

                //Direcciones Rosa de Los Vientos
                if (x2=="000")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Norte;
                }
                else if (x2 == "001")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Noreste;
                }
                else if (x2 == "010")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Este;
                }
                else if (x2 == "011")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Sureste;
                }
                else if (x2 == "100")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Sur;
                }
                else if (x2 == "101")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Suroeste;
                }
                else if (x2 == "110")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Oeste;
                }
                else if (x2 == "111")
                {
                    pBoxDireccion.Image = PracticaBits.Properties.Resources.Noroeste;
                }
                else
                {
                    MessageBox.Show("Ingrese un ID correcto");
                }
            }


        }

        private void btnFecha_Click(object sender, EventArgs e)
        {
            DateTime Date = laFecha.Value;
            int year = Date.Year;
            int month = Date.Month;
            int day = Date.Day;

            int sizeYear;
            int sizeMonth;
            int sizeDay;

            year = year-118;
            
            string yearx = Convert.ToString(year, 2);
            string monthx = Convert.ToString(month, 2);
            string dayx = Convert.ToString(day, 2);
            string dateBin = "";

            sizeYear = yearx.Length;
            sizeMonth = monthx.Length;
            sizeDay = dayx.Length;

            int[] z = new int[3];

            z[0] = 7 - sizeYear;
            z[1] = 4 - sizeMonth;
            z[2] = 5 - sizeDay;
            //_________________________________________________//
            int z1 = 0;
            string s1 = "";
            string s2 = "";
            string s3 = "";
           

            for (int h = sizeYear; h <=6; h++)
            {
                z1++;
                s1 += "0";
            }

            for (int c = sizeMonth; c <=3 ; c++)
            {
                z1++;
                s2 += "0";
            }

            for (int v = sizeYear; v <=4; v++)
            {
              
                s3 += "0";

                z1++;
            }

            yearx = s1 + "" + yearx;
            dayx = s3 + "" + dayx;
            monthx = s2 + "" + monthx;
            dateBin = yearx + ""              + monthx + "" +dayx; 
            //Concatenando

            int w = 0;
           

            for ( int t = 0 ,  i = dateBin.Length - 1;  i >= 0;  t++ ,  i--)
            {



                if (dateBin[i] == '1'      ||      dateBin[i] == '0')
                {



                    w += ( int) Math.Pow(2, t)*(int.Parse  (  dateBin[ i ].ToString() ) )
                        
                        ;
                }







            }


            textBoxFecha.Text = w.ToString();





            label5.Text =  dateBin + "/" + w;
            
        }

    }


        }
    



